import numpy as np
import pandas as pd
from typing import Dict, List
from sklearn.metrics.pairwise import cosine_similarity

def compute_similarity_matrix(df: pd.DataFrame, features: List[str]) -> np.ndarray:
    if not features:
        return np.zeros((len(df), len(df)))
    X = df[features].to_numpy(dtype=float)
    return cosine_similarity(X)

def content_based(df: pd.DataFrame, sim_mat: np.ndarray, title: str, limit: int = 5, feature_weights: Dict[str, float] = None, features: List[str] = None) -> List[Dict]:
    if feature_weights and features:
        w = np.ones(len(features), dtype=float)
        for i, fname in enumerate(features):
            if fname in feature_weights:
                w[i] = float(feature_weights[fname])
        from sklearn.metrics.pairwise import cosine_similarity
        X = (df[features].to_numpy(dtype=float) * w)
        sim_mat = cosine_similarity(X)

    idx = df.index[df["title"].str.lower() == str(title).lower()].tolist()
    if not idx:
        return []
    i = idx[0]
    sims = sim_mat[i]
    order = np.argsort(-sims)
    recs: List[Dict] = []
    for j in order:
        if j == i:
            continue
        recs.append({
            "posicao": len(recs)+1,
            "id_musica": int(df.loc[j, "song_id"]),
            "titulo": str(df.loc[j, "title"]),
            "artista": str(df.loc[j, "artist"]),
            "genero": str(df.loc[j, "genre"]),
            "ano": int(df.loc[j, "year"]) if not pd.isna(df.loc[j, "year"]) else None,
            "score": float(sims[j])
        })
        if len(recs) >= limit:
            break
    return recs

def genre_artist(df: pd.DataFrame, genre: str = None, artist: str = None, limit: int = 5) -> List[Dict]:
    q = df.copy()
    if genre:
        q = q[q["genre"].astype(str).str.lower().str.contains(genre.lower(), na=False)]
    if artist:
        q = q[q["artist"].astype(str).str.lower().str.contains(artist.lower(), na=False)]
    if "popularity" in q.columns and q["popularity"].notnull().any():
        q = q.sort_values("popularity", ascending=False, na_position="last")
    elif "year" in q.columns:
        q = q.sort_values("year", ascending=False, na_position="last")
    return _rows_to_list(q.head(limit))

def popular(df: pd.DataFrame, year: int = None, genre: str = None, limit: int = 5) -> List[Dict]:
    q = df.copy()
    if year is not None and "year" in q.columns:
        q = q[q["year"] == year]
    if genre:
        q = q[q["genre"].astype(str).str.lower().str.contains(genre.lower(), na=False)]
    if "popularity" in q.columns and q["popularity"].notnull().any():
        q = q.sort_values("popularity", ascending=False, na_position="last")
    elif "year" in q.columns:
        q = q.sort_values("year", ascending=False, na_position="last")
    return _rows_to_list(q.head(limit))

def _rows_to_list(df_part: pd.DataFrame) -> List[Dict]:
    out: List[Dict] = []
    for _, r in df_part.iterrows():
        out.append({
            "id_musica": int(r["song_id"]),
            "titulo": str(r["title"]),
            "artista": str(r["artist"]),
            "genero": str(r["genre"]),
            "ano": int(r["year"]) if not pd.isna(r["year"]) else None,
            "popularidade": float(r["popularity"]) if "popularity" in r and not pd.isna(r["popularity"]) else None
        })
    return out

def build_fake_user_interactions(df: pd.DataFrame, n_users: int = 60, seed: int = 42):
    rng = np.random.default_rng(seed)
    users = {}
    genres = df["genre"].astype(str).fillna("").unique().tolist()
    artists = df["artist"].astype(str).fillna("").unique().tolist()

    for u in range(n_users):
        uid = f"u_{u:03d}"
        liked = set()
        g = rng.choice(genres) if genres else ""
        a = rng.choice(artists) if artists else ""
        g_pool = df[df["genre"].astype(str) == g]["song_id"].tolist()
        a_pool = df[df["artist"].astype(str) == a]["song_id"].tolist()
        rand_pool = df["song_id"].sample(min(10, len(df)), random_state=int(seed+u)).tolist()

        for pool, k in [(g_pool, 10), (a_pool, 10), (rand_pool, 10)]:
            from numpy.random import default_rng
            picks = rng.choice(pool, size=min(k, len(pool)), replace=False).tolist() if pool else []
            liked.update(picks)
        users[uid] = sorted(liked)
    return users

def collaborative_recs(df: pd.DataFrame, interactions, user_id: str, limit: int = 5) -> List[Dict]:
    if user_id not in interactions:
        return []
    target = set(interactions[user_id])
    sims = []
    for uid, items in interactions.items():
        if uid == user_id:
            continue
        s = set(items)
        inter = len(target & s)
        union = len(target | s) or 1
        jac = inter / union
        sims.append((uid, jac))
    sims.sort(key=lambda x: x[1], reverse=True)
    top_neighbors = [uid for uid, score in sims[:10] if score > 0]

    counts = {}
    for uid in top_neighbors:
        for sid in interactions[uid]:
            if sid in target:
                continue
            counts[sid] = counts.get(sid, 0) + 1

    ranked = sorted(counts.items(), key=lambda x: x[1], reverse=True)
    out: List[Dict] = []
    for sid, score in ranked[:limit]:
        row = df[df["song_id"] == sid].head(1)
        if row.empty:
            continue
        r = row.iloc[0]
        out.append({
            "id_musica": int(r["song_id"]),
            "titulo": str(r["title"]),
            "artista": str(r["artist"]),
            "genero": str(r["genre"]),
            "ano": int(r["year"]) if not pd.isna(r["year"]) else None,
            "score": float(score)
        })
    return out

def hybrid(df: pd.DataFrame, sim_mat: np.ndarray, features: List[str], interactions, song_title: str, user_id: str, content_weight: float = 0.7, collab_weight: float = 0.3, limit: int = 5) -> List[Dict]:
    cb_list = content_based(df, sim_mat, song_title, limit=len(df), features=features)
    cb_scores = { r.get("id_musica") or r.get("song_id", None): r["score"] for r in cb_list }
    coll_list = collaborative_recs(df, interactions, user_id, limit=len(df))
    coll_scores = { r.get("id_musica") or r.get("song_id", None): r["score"] for r in coll_list }

    all_ids = set([k for k in cb_scores.keys() if k is not None]) | set([k for k in coll_scores.keys() if k is not None])

    def norm(scores: Dict[int, float]):
        if not scores:
            return {}
        import numpy as np
        vals = np.array(list(scores.values()), dtype=float)
        lo, hi = float(vals.min()), float(vals.max())
        if hi == lo:
            return {k: 0.0 for k in scores}
        return {k: (v - lo) / (hi - lo) for k, v in scores.items()}

    cbn = norm(cb_scores)
    coln = norm(coll_scores)

    combo: List[Dict] = []
    title_lower = str(song_title).lower()
    for sid in all_ids:
        score = content_weight * cbn.get(sid, 0.0) + collab_weight * coln.get(sid, 0.0)
        row = df[df["song_id"] == sid].head(1)
        if row.empty:
            continue
        r = row.iloc[0]
        if str(r["title"]).lower() == title_lower:
            continue
        combo.append({
            "id_musica": int(r["song_id"]),
            "titulo": str(r["title"]),
            "artista": str(r["artist"]),
            "genero": str(r["genre"]),
            "ano": int(r["year"]) if not pd.isna(r["year"]) else None,
            "score": float(score)
        })
    combo.sort(key=lambda x: x["score"], reverse=True)
    return combo[:limit]
