import os
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from typing import List, Dict, Tuple

CANON = {
    "title": ["Title", "Track.Name", "track_name", "title", "Song", "song_title"],
    "artist": ["Artist", "Artist.Name", "artist", "artist_name", "Artist(s)", "artist(s)_name"],
    "genre": ["Genre", "genre", "Top.Genre", "top_genre"],
    "year": ["Year", "year", "Released.Year", "released_year"],
    "popularity": ["Popularity", "popularity", "Streams", "streams", "in_spotify_playlists"],
    "Beats.Per.Minute": ["Beats.Per.Minute", "bpm", "BPM"],
    "Energy": ["Energy", "energy", "Energy.%", "energy_%"],
    "Danceability": ["Danceability", "danceability", "Danceability.%", "danceability_%"],
    "Loudness/dB": ["Loudness/dB", "loudness", "loudness_db"],
    "Liveness": ["Liveness", "liveness"],
    "Valence": ["Valence", "valence", "Valence.%", "valence_%"],
    "Length": ["Length", "duration_ms", "Duration", "length"],
    "Acousticness": ["Acousticness", "acousticness"],
    "Speechiness": ["Speechiness", "speechiness"],
}

FEATURES_ORDER = [
    "Beats.Per.Minute", "Energy", "Danceability",
    "Loudness/dB", "Liveness", "Valence",
    "Length", "Acousticness", "Speechiness", "popularity"
]

def _find_col(df: pd.DataFrame, candidates: List[str]) -> str:
    for c in candidates:
        if c in df.columns:
            return c
        for col in df.columns:
            if col.lower() == c.lower():
                return col
    return ""

def load_dataset(csv_path: str) -> Tuple[pd.DataFrame, Dict[str, str], List[str], MinMaxScaler]:
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"CSV não encontrado em {csv_path}")
    df_raw = pd.read_csv(csv_path)
    colmap: Dict[str, str] = {}

    for logical, candidates in CANON.items():
        found = _find_col(df_raw, candidates)
        if found:
            colmap[logical] = found

    df = pd.DataFrame()
    for logical in ["title", "artist", "genre", "year", "popularity"]:
        df[logical] = df_raw[colmap[logical]] if logical in colmap else np.nan

    if "year" in df.columns:
        df["year"] = pd.to_numeric(df["year"], errors="coerce").astype("Int64")
    if "popularity" in df.columns:
        df["popularity"] = pd.to_numeric(df["popularity"], errors="coerce")

    features: List[str] = []
    for feat in FEATURES_ORDER:
        actual = colmap.get(feat, "")
        if actual and actual in df_raw.columns:
            df[feat] = pd.to_numeric(df_raw[actual], errors="coerce")
            features.append(feat)

    if "popularity" in df.columns and df["popularity"].notnull().any():
        if "popularity" not in features:
            features.append("popularity")

    df[features] = df[features].replace([np.inf, -np.inf], np.nan)
    df[features] = df[features].fillna(df[features].median(numeric_only=True))

    scaler = MinMaxScaler()
    if features:
        df[features] = scaler.fit_transform(df[features])

    df["song_id"] = (
        df[["title", "artist"]]
        .astype(str)
        .agg("-".join, axis=1)
        .apply(lambda s: abs(hash(s)) % (10**12))
    ).astype("int64")

    df = df.drop_duplicates(subset=["title", "artist"], keep="first").reset_index(drop=True)
    return df, colmap, features, scaler
