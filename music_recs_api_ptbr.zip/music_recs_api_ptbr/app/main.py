from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from .routers.recomendacoes import router as recs_router
from .state import init_state

app = FastAPI(
    title="API de Recomendação Musical",
    version="1.0.0",
    description="Endpoints em português: por conteúdo, por gênero/artista, colaborativa (simulada), híbrida e populares por ano/gênero.",
)

@app.on_event("startup")
def _startup():
    csv_path = "app/data/top50MusicFrom2010-2019.csv"
    init_state(csv_path)

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
def home():
    return """
    <!doctype html>
    <html lang="pt-br">
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>API de Recomendação Musical</title>
        <style>
          body { font-family: system-ui, -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; margin: 40px; color: #1a1a1a; }
          h1 { margin-bottom: 0.25rem; }
          .muted { color: #666; }
          .card { border: 1px solid #e5e5e5; border-radius: 12px; padding: 16px; margin: 12px 0; }
          code { background: #f6f8fa; padding: 2px 6px; border-radius: 6px; }
          a { color: #0b7285; text-decoration: none; }
          a:hover { text-decoration: underline; }
          ul { line-height: 1.7; }
          .btn { display:inline-block; padding:10px 14px; border-radius:10px; border:1px solid #0b7285; }
        </style>
      </head>
      <body>
        <h1>API de Recomendação Musical</h1>
        <p class="muted">FastAPI · pt-BR</p>

        <div class="card">
          <h3>Documentação</h3>
          <p><a class="btn" href="/docs">Swagger UI</a> &nbsp; <a class="btn" href="/redoc">ReDoc</a></p>
        </div>

        <div class="card">
          <h3>Endpoints</h3>
          <ul>
            <li><code>GET /recomendacoes/conteudo/{titulo_musica}?limite=5</code></li>
            <li><code>POST /recomendacoes/genero-artista</code></li>
            <li><code>GET /recomendacoes/colaborativa/{usuario_id}?limite=5</code></li>
            <li><code>POST /recomendacoes/hibrida</code></li>
            <li><code>GET /recomendacoes/populares?ano=2017&genero=Pop&limite=5</code></li>
          </ul>
        </div>

        <div class="card">
          <h3>Exemplos rápidos</h3>
          <p><code>GET /health</code> → retorna status</p>
          <p><code>GET /recomendacoes/populares?limite=3</code></p>
        </div>

        <p class="muted">Dica: use <a href="/docs">/docs</a> para testar com "Try it out".</p>
      </body>
    </html>
    """

app.include_router(recs_router)

@app.get("/health")
def health():
    return {"status": "ok"}
