from dataclasses import dataclass
from typing import List, Dict
import numpy as np
import pandas as pd

from .core.data_loader import load_dataset
from .core.recommender import compute_similarity_matrix, build_fake_user_interactions

@dataclass
class AppState:
    df: pd.DataFrame
    features: List[str]
    similarity: np.ndarray
    interactions: Dict[str, list]

_state = None

def init_state(csv_path: str):
    global _state
    df, colmap, features, scaler = load_dataset(csv_path)
    sim = compute_similarity_matrix(df, features)
    interactions = build_fake_user_interactions(df, n_users=60, seed=42)
    _state = AppState(df=df, features=features, similarity=sim, interactions=interactions)
    return _state

def get_state() -> AppState:
    if _state is None:
        raise RuntimeError("Estado do app não inicializado")
    return _state
