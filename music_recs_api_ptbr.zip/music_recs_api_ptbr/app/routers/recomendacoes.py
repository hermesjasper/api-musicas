from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from typing import Optional
import json

from ..state import get_state
from ..core.recommender import content_based, genre_artist, popular, collaborative_recs, hybrid

router = APIRouter(prefix="/recomendacoes", tags=["Recomendações"])

class GeneroArtistaPedido(BaseModel):
    genero: Optional[str] = None
    artista: Optional[str] = None
    limite: int = Field(default=5, ge=1, le=50)

class HibridaPedido(BaseModel):
    titulo_musica: str
    usuario_id: str
    peso_conteudo: float = Field(default=0.7, ge=0, le=1)
    peso_colaborativa: float = Field(default=0.3, ge=0, le=1)
    limite: int = Field(default=5, ge=1, le=50)

@router.get("/conteudo/{titulo_musica}")
def recomendacoes_por_conteudo(
    titulo_musica: str,
    limite: int = Query(default=5, ge=1, le=50),
    pesos: Optional[str] = Query(default=None, description="JSON com pesos de features (ex.: {\"Energy\":2.0,\"Danceability\":1.2})")
):
    st = get_state()
    try:
        pesos_features = json.loads(pesos) if pesos else None
    except Exception:
        raise HTTPException(status_code=400, detail="JSON inválido no parâmetro 'pesos'")
    recs = content_based(st.df, st.similarity, titulo_musica, limit=limite, feature_weights=pesos_features, features=st.features)
    if not recs:
        raise HTTPException(status_code=404, detail="Música não encontrada ou sem recomendações")
    return {"consulta": titulo_musica, "limite": limite, "resultados": recs}

@router.post("/genero-artista")
def recomendacoes_por_genero_artista(pedido: GeneroArtistaPedido):
    st = get_state()
    recs = genre_artist(st.df, genre=pedido.genero, artist=pedido.artista, limit=pedido.limite)
    return {"genero": pedido.genero, "artista": pedido.artista, "limite": pedido.limite, "resultados": recs}

@router.get("/colaborativa/{usuario_id}")
def recomendacoes_colaborativas(usuario_id: str, limite: int = Query(default=5, ge=1, le=50)):
    st = get_state()
    recs = collaborative_recs(st.df, st.interactions, user_id=usuario_id, limit=limite)
    if not recs:
        raise HTTPException(status_code=404, detail="Usuário desconhecido ou sem recomendações")
    return {"usuario_id": usuario_id, "limite": limite, "resultados": recs}

@router.post("/hibrida")
def recomendacoes_hibridas(pedido: HibridaPedido):
    st = get_state()
    recs = hybrid(st.df, st.similarity, st.features, st.interactions, pedido.titulo_musica, pedido.usuario_id, pedido.peso_conteudo, pedido.peso_colaborativa, pedido.limite)
    if not recs:
        raise HTTPException(status_code=404, detail="Sem recomendações híbridas para os parâmetros informados")
    return {
        "titulo_musica": pedido.titulo_musica,
        "usuario_id": pedido.usuario_id,
        "peso_conteudo": pedido.peso_conteudo,
        "peso_colaborativa": pedido.peso_colaborativa,
        "limite": pedido.limite,
        "resultados": recs
    }

@router.get("/populares")
def recomendacoes_populares(ano: Optional[int] = None, genero: Optional[str] = None, limite: int = Query(default=5, ge=1, le=50)):
    st = get_state()
    recs = popular(st.df, year=ano, genre=genero, limit=limite)
    return {"ano": ano, "genero": genero, "limite": limite, "resultados": recs}
