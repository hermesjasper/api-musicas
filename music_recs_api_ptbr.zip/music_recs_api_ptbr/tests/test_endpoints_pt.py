from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"

def test_populares():
    r = client.get("/recomendacoes/populares?limite=2")
    assert r.status_code == 200
    data = r.json()
    assert "resultados" in data

def test_genero_artista_post():
    r = client.post("/recomendacoes/genero-artista", json={"genero": "pop", "artista": None, "limite": 2})
    assert r.status_code == 200

def test_conteudo_not_found():
    r = client.get("/recomendacoes/conteudo/naoexiste123")
    assert r.status_code == 404
